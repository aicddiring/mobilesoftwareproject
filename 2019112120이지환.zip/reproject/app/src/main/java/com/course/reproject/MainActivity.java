package com.course.reproject;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.ArrayList;


@SuppressWarnings("deprecation")
public class MainActivity extends AppCompatActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private RecyclerView myRecyclerView;
    private RecyclerView myRecyclerView2;
    private RecyclerView.LayoutManager myLayoutManager;
    private RecyclerView.LayoutManager myLayoutManager2;

    RadioButton rdoRed;
    RadioButton rdoGreen;
    RadioButton rdoBlue;

    Button MUSTIT;
    Button BALAAN;
    Button b1;

    LinearLayout colorLayout;
    TextView tv;
    WebView wv;
    int rot = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1 = (Button)findViewById(R.id.call);

        TabHost tabHost = findViewById(R.id.tabhost);
        tabHost.setup();

        TabHost.TabSpec tabSpecColor = tabHost.newTabSpec("UNDER").setIndicator("50만원 미만");
        tabSpecColor.setContent(R.id.colorLayout);
        tabHost.addTab(tabSpecColor);

        TabHost.TabSpec tabSpecRota = tabHost.newTabSpec("UPPER").setIndicator("가격비교");
        tabSpecRota.setContent(R.id.rotationLayout);
        tabHost.addTab(tabSpecRota);

        tabHost.setCurrentTab(0);

        rdoRed          = (RadioButton) findViewById(R.id.rdoRed);
        rdoBlue         = (RadioButton) findViewById(R.id.rdoBlue);
        rdoGreen        = (RadioButton) findViewById(R.id.rdoGreen);

        MUSTIT = (Button) findViewById(R.id.btnLeft);
        BALAAN = (Button) findViewById(R.id.btnRight);

        colorLayout     = (LinearLayout) findViewById(R.id.colorLayout);

        rdoRed.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View view) {
                colorLayout.setBackgroundColor(Color.RED);
            }
        });

        rdoGreen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                colorLayout.setBackgroundColor(Color.GREEN);
            }
        });

        rdoBlue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                colorLayout.setBackgroundColor(Color.BLUE);
            }
        });


        b1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_VIEW,
                        Uri.parse("tel:01059223812"));
                startActivity(intent);
            }
        });
        Button startBtn = (Button) findViewById(R.id.sendEmail);
        startBtn.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View view) {
                sendEmail();
            }
        });

        myRecyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        myRecyclerView.setHasFixedSize(true);
        myLayoutManager = new LinearLayoutManager(this);
        myRecyclerView.setLayoutManager(myLayoutManager);


        ArrayList<bag> bagsInfo = new ArrayList<>();
        bagsInfo.add(new bag(R.drawable.first,"오프화이트 남성 클러치 백", "https://www.balaan.co.kr/shop/goods/goods_view.php?goodsno=5966176","https://www.off---white.com/en-us" ));
        bagsInfo.add(new bag(R.drawable.second, "[몽블랑 MONTBLANC] 124124 여성 파우치백", "https://www.balaan.co.kr/shop/goods/goods_view.php?goodsno=10082940", "https://www.montblanc.com/ko-kr/home.html"));
        bagsInfo.add(new bag(R.drawable.third, "메종마르지엘라 남성 클러치백", "https://www.balaan.co.kr/shop/goods/goods_view.php?goodsno=3548846","https://www.maisonmargiela.com/kr"));
        bagsInfo.add(new bag(R.drawable.fourth, "코치 남성 클러치 백", "https://www.balaan.co.kr/shop/goods/goods_view.php?goodsno=5854366","https://korea.coach.com/"));
        bagsInfo.add(new bag(R.drawable.fifth,"21FW 발리 남성 클러치백","https://www.balaan.co.kr/shop/goods/goods_view.php?goodsno=7283080", "https://www.ballyofswitzerland.com/en/home"));
        bagsInfo.add(new bag(R.drawable.sixth, "21SS 꼼데가르송월렛 남성 클러치백", "https://www.balaan.co.kr/shop/goods/goods_view.php?goodsno=6939023","https://www.comme-des-garcons.com/"));
        bagsInfo.add(new bag(R.drawable.seventh, "로조 34136 HSG 037 공용 클러치/파우치백", "https://www.balaan.co.kr/shop/goods/goods_view.php?goodsno=9396603","https://www.longchamp.com/kr/ko"));
        bagsInfo.add(new bag(R.drawable.eighth, "베르사체 21FW 71YA5P90ZS108", "https://www.balaan.co.kr/shop/goods/goods_view.php?goodsno=10472984","https://www.versace.com/international/en/home/?glCountry=KR"));
        bagsInfo.add(new bag(R.drawable.nineth,"겐조 남성 클러치 백", "https://www.balaan.co.kr/shop/goods/goods_view.php?goodsno=5275586","https://www.kenzo.com/eu/en/home"));
        bagsInfo.add(new bag(R.drawable.tenth, "생로랑 타이니 실버 로고 클러치백 607779 1JB0E 1000", "https://www.balaan.co.kr/shop/goods/goods_view.php?goodsno=10808817","https://www.ysl.com/ko-kr"));
        MyAdapter myAdapter = new MyAdapter(bagsInfo);
        myRecyclerView.setAdapter(myAdapter);

        wv =(WebView) findViewById(R.id.webView);

        wv.setWebViewClient(new wwv());
        WebSettings webSet = wv.getSettings();
        webSet.setJavaScriptEnabled(true);
        webSet.setBuiltInZoomControls(true);

        MUSTIT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                wv.loadUrl("https://mustit.co.kr");
            }
        });

        BALAAN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                wv.loadUrl("https://www.balaan.co.kr");
            }
        });

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    protected void sendEmail() {
        String[] TO = {"flyboys1@naver.com"};
        String[] CC = {""};
        Intent emailIntent = new Intent(Intent.ACTION_SEND);
        emailIntent.setData(Uri.parse("mailto:"));
        emailIntent.setType("text/plain");
        emailIntent.putExtra(Intent.EXTRA_EMAIL, TO);
        emailIntent.putExtra(Intent.EXTRA_CC, CC);
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, "(ICE.COM) 문의내역 : ");
        emailIntent.putExtra(Intent.EXTRA_TEXT, "문의내역");
        try {
            startActivity(Intent.createChooser(emailIntent, "이메일 보내기..."));
            finish();
        } catch (android.content.ActivityNotFoundException ex)
        {
            Toast.makeText(MainActivity.this, "이메일 클라이언트가 없네요.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        // 마커를 동국대로 위치시키고 카메라를 이동시킴
        LatLng dongguk = new LatLng(37.55827, 126.998425);
        // 마커에 대한 옵션 설정
        MarkerOptions markerOptions = new MarkerOptions();
        markerOptions.position(dongguk);
        markerOptions.title("동국대학교");
        markerOptions.snippet("지금 있는 곳");
        mMap.addMarker(markerOptions);
        // 줌 기능 활성화
        mMap.getUiSettings().setZoomGesturesEnabled(true);
        // 현재 위치로 이동

        mMap.moveCamera(CameraUpdateFactory.newLatLng(dongguk));
        // 줌 레벨 설정
        mMap.animateCamera(CameraUpdateFactory.zoomTo(15));
    }
    class wwv extends WebViewClient{
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url){
            return super.shouldOverrideUrlLoading(view, url);
        }
    }
}