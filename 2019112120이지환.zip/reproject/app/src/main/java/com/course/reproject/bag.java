package com.course.reproject;

public class bag {
    String bag_name;
    int image_id;
    String detail_url;
    String official_url;
    public bag(int id, String name, String durl, String url) {
        this.image_id = id;
        this.bag_name = name;
        this.detail_url = durl;
        this.official_url = url;
    }
    public String getSchoolName() {
        return bag_name;
    }
    public int getImageID() {
        return image_id;
    }
    public String getdetailURL() {
        return detail_url;
    }
    public String getstoreURL() {
        return official_url;
    }
}
